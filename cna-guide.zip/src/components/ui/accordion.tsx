import React from "react";
export const Accordion = ({children}: any) => <div>{children}</div>;
export const AccordionItem = ({children}: any) => <div className="border-b border-zinc-200 dark:border-zinc-800">{children}</div>;
export const AccordionTrigger = ({children}: any) => <button className="w-full text-left py-3 font-medium">{children}</button>;
export const AccordionContent = ({children}: any) => <div className="pb-4 text-sm text-zinc-600 dark:text-zinc-300">{children}</div>;
