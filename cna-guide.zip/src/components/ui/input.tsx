import React from "react";
export const Input = (props: any) => <input {...props} />;
