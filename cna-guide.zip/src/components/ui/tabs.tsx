import React from "react";
export const Tabs = ({children}: any) => <div>{children}</div>;
export const TabsList = ({children}: any) => <div className="mb-2 inline-flex gap-2">{children}</div>;
export const TabsTrigger = ({children, ...props}: any) => <button className="btn" {...props}>{children}</button>;
export const TabsContent = ({children}: any) => <div className="mt-2">{children}</div>;
