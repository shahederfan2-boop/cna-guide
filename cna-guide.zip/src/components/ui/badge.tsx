import React from "react";
export const Badge = ({children, className=""}: any) => <span className={`badge ${className}`}>{children}</span>;
