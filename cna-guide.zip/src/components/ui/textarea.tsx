import React from "react";
export const Textarea = (props: any) => <textarea {...props} />;
