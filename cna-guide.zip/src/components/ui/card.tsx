import React from "react";
export const Card = ({ className="", children, ...props }: any) => <div className={`card ${className}`} {...props}>{children}</div>;
export const CardHeader = ({ children, className="" }: any) => <div className={`p-4 ${className}`}>{children}</div>;
export const CardTitle = ({ children, className="" }: any) => <h3 className={`text-lg font-semibold ${className}`}>{children}</h3>;
export const CardContent = ({ children, className="" }: any) => <div className={`p-4 pt-0 ${className}`}>{children}</div>;
