export const Separator = () => <div className="my-4 h-px bg-zinc-200 dark:bg-zinc-800" />;
