import React from "react";
export const Checkbox = ({checked, onCheckedChange, id}: any) => (
  <input id={id} type="checkbox" checked={!!checked} onChange={onCheckedChange} className="h-4 w-4" />
);
