import React from "react";
export const Sheet = ({children}: any) => <div className="inline-flex items-center gap-2">{children}</div>;
export const SheetTrigger = ({children}: any) => <>{children}</>;
export const SheetContent = ({children}: any) => <div className="fixed right-4 top-16 z-50 w-64 rounded-xl border bg-white p-4 shadow-lg dark:bg-zinc-900">{children}</div>;
export const SheetHeader = ({children}: any) => <div className="mb-2">{children}</div>;
export const SheetTitle = ({children}: any) => <h4 className="text-base font-semibold">{children}</h4>;
