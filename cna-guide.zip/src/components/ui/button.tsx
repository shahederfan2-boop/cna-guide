import React from "react";
export const Button = ({ className="", variant, size, asChild, children, ...props }: any) => {
  const base = "btn";
  const style = variant==="outline" ? "border" : variant==="ghost" ? "bg-transparent border border-transparent" : "btn-primary";
  return React.createElement(asChild ? 'a' : 'button', { className: `${base} ${style} ${className}`, ...props }, children);
};
