import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Search, Stethoscope, ListChecks, GraduationCap, FileDown, Moon, Sun, Menu, ClipboardCheck, Info, Clock, Phone, Mail } from "lucide-react";

// CNA Guide — one-file site
// Sections: Overview, Skills (critical steps), Practice (MCQ quiz), Planner, Resources, FAQ, Contact
// Print-friendly: use the Print button (ctrl/cmd + P) to save as PDF.

const skills = [
  { id: "hand-hygiene", name: "Hand Hygiene (Handwashing)", category: "Infection Control", time: "~40–60 seconds", critical: [
    "Wet hands, apply soap; lather including wrists, nails, and between fingers.",
    "Scrub for a full 20 seconds (hum 'Happy Birthday' twice).",
    "Rinse with fingertips down; do not touch sink.",
    "Dry with clean paper towel(s).",
    "Use a new towel to turn off faucet without recontaminating hands.",
  ]},
  { id: "donning-doffing-ppe", name: "Donning & Removing PPE (Gown & Gloves)", category: "Infection Control", time: "~1–2 minutes", critical: [
    "Tie neck and waist securely; cuffs inside glove cuffs.",
    "Remove gloves first: grasp palm to palm, then slip finger under cuff.",
    "Untie without touching front; roll gown inside-out; discard properly.",
    "Hand hygiene immediately after removal.",
  ]},
  { id: "measure-bp", name: "Measure Blood Pressure (Manual)", category: "Vitals", time: "~2–3 minutes", critical: [
    "Clean earpieces/diaphragm; expose arm, palm up, supported at heart level.",
    "Place cuff 1 inch above antecubital; locate brachial artery.",
    "Inflate 20–30 mmHg above radial stop; deflate 2–4 mmHg/sec.",
    "Report/record systolic/diastolic within ±4 mmHg of evaluator.",
    "Perform hand hygiene; ensure resident comfort & safety.",
  ]},
  { id: "radial-pulse", name: "Measure Radial Pulse", category: "Vitals", time: "~1–2 minutes", critical: [
    "Locate radial pulse with fingertips (not thumb).",
    "Count for full 60 seconds (or 30×2 if policy allows).",
    "Record within ±4 beats of evaluator; hand hygiene.",
  ]},
  { id: "respirations", name: "Measure Respirations", category: "Vitals", time: "~1–2 minutes", critical: [
    "Observe chest rise discreetly; do not announce.",
    "Count full 60 seconds; normal adult 12–20.",
    "Record within ±2 breaths of evaluator; hand hygiene.",
  ]},
  { id: "weight-scale", name: "Measure Weight (Standing Scale)", category: "Measurement", time: "~2–3 minutes", critical: [
    "Zero scale; client shoes on/off per protocol, non-skid footwear.",
    "Assist safely; ensure balance; read level at eye height.",
    "Record weight within ±0.25 lb (or per metric tolerance).",
  ]},
  { id: "urinary-output", name: "Urinary Output (Graduated Cylinder)", category: "Measurement", time: "~2 minutes", critical: [
    "Gloves; pour from bedpan/urinal into graduate away from you.",
    "Measure at eye level on flat surface.",
    "Empty contents into toilet; rinse; record within ±25 mL; hand hygiene.",
  ]},
  { id: "ambulation-belt", name: "Ambulation with Gait Belt", category: "Mobility & Safety", time: "~2–3 minutes", critical: [
    "Lock bed/wheels; client wearing non-skid footwear.",
    "Apply belt snug (two-finger rule); signal count to stand.",
    "Stand slightly behind/side; hold belt underhand; monitor dizziness.",
    "Walk 10 feet; return, remove belt; call light within reach; bed low.",
  ]},
  { id: "transfer-wheelchair", name: "Transfer to Wheelchair (Gait Belt)", category: "Mobility & Safety", time: "~3–4 minutes", critical: [
    "Position wheelchair at bed, lock wheels, footrests out of way.",
    "Bed low; non-skid footwear; belt snug; count of three to stand.",
    "Pivot to align with chair; ensure hips to back; feet on rests; call light.",
  ]},
  { id: "position-side", name: "Position on Side (Lateral)", category: "Positioning", time: "~3–4 minutes", critical: [
    "Raise side rail; roll client safely onto side facing you.",
    "Support head, back, top arm, and between knees with pillows.",
    "Check alignment: not lying on arm, call light in reach, bed low/locked.",
  ]},
  { id: "rom-shoulder", name: "Range of Motion — Shoulder", category: "ROM", time: "~2–3 minutes", critical: [
    "Support joints; instruct to report pain; move slowly.",
    "Flexion/extension 3×; abduction/adduction 3× within comfort.",
    "Stop if pain; hand hygiene; call light.",
  ]},
  { id: "rom-knee-ankle", name: "Range of Motion — Knee & Ankle", category: "ROM", time: "~2–3 minutes", critical: [
    "Support knee and ankle; flex/extend knee 3×; dorsiflex/plantarflex ankle 3×.",
    "Ask about pain each set; move smoothly; no hyperextension.",
  ]},
  { id: "bedpan", name: "Bedpan (Standard/Fracture) & Output", category: "Elimination", time: "~4–5 minutes", critical: [
    "Privacy; hand hygiene; gloves on.",
    "Place pan correctly; head of bed up; toilet tissue & hand wipe within reach.",
    "Remove pan safely; measure output at eye level on flat surface.",
    "Empty into toilet; rinse equipment; remove gloves; hand hygiene.",
    "Record accurately (±25 mL).",
  ]},
  { id: "feeding", name: "Feeding (Upright Resident)", category: "Nutrition", time: "~5–7 minutes", critical: [
    "Verify name/diet card; raise HOB 75–90°; hand hygiene for client.",
    "Small bites/sips; describe food; check for swallowing; clean mouth/hands.",
    "Record intake % and fluids in mL accurately.",
  ]},
  { id: "mouth-care", name: "Mouth Care (Conscious Resident)", category: "Hygiene", time: "~3–4 minutes", critical: [
    "Clothing protector; moisten brush with toothpaste.",
    "Brush all surfaces incl. tongue; gentle strokes.",
    "Offer rinse; wipe mouth; remove protector.",
    "Rinse basin, toothbrush; gloves off; hand hygiene.",
  ]},
  { id: "foot-care", name: "Foot Care (One Foot)", category: "Hygiene", time: "~5–6 minutes", critical: [
    "Basin warm; support foot; wash, rinse, dry between toes (no lotion between toes).",
    "Apply lotion top/bottom; remove excess; safety & hand hygiene.",
  ]},
  { id: "catheter-care", name: "Catheter Care (Female)", category: "Hygiene", time: "~5–6 minutes", critical: [
    "Gloves; linen protector; expose only perineal area (privacy).",
    "Clean meatus outward along catheter 4 inches; new area of cloth each stroke.",
    "Rinse and pat dry front-to-back; avoid tugging; secure tubing.",
    "Remove linen protector; dispose; hand hygiene.",
  ]},
  { id: "peri-care-female", name: "Perineal Care (Female)", category: "Hygiene", time: "~6–7 minutes", critical: [
    "Warm water; front-to-back; clean to dirty with new area of cloth each stroke.",
    "Rinse and dry front-to-back; privacy and dignity maintained.",
    "Dispose linens properly; hand hygiene; call light.",
  ]},
  { id: "dress-affected-arm", name: "Dressing with Affected (Weak) Arm", category: "ADLs", time: "~4–5 minutes", critical: [
    "Undress strong first; dress weak first (shirt sleeve).",
    "Support affected arm; maintain privacy; place dirty linen in hamper.",
  ]},
];

const sampleQuestions = [
  { id: 1, q: "During hand hygiene, which action prevents recontamination right before you finish?", options: [
      "Dry hands from wrists to fingers",
      "Turn off faucet with a clean paper towel",
      "Rinse with hands cupped upward",
      "Use warm air dryer for 10 seconds",
    ], answer: 1, rationale: "Use a clean barrier (towel) to shut off water; otherwise you touch a dirty surface." },
  { id: 2, q: "The blood pressure reading must be within what range of the evaluator’s reading to pass?", options: ["±2 mmHg", "±4 mmHg", "±6 mmHg", "±8 mmHg"], answer: 1, rationale: "Most state skills exams accept ±4 mmHg for manual BP." },
  { id: 3, q: "Before ambulating a client with a gait belt, what TWO safety controls must be confirmed?", options: [
      "Bed low & wheels locked",
      "Call light present",
      "Client wearing non-skid footwear",
      "Room door closed",
    ], answer: [0,2], multi: true, rationale: "Locked bed/wheels and non-skid footwear are critical for fall prevention." },
  { id: 4, q: "When measuring respirations, the best practice is to…", options: [
      "Ask the client to breathe normally",
      "Count right after telling them",
      "Observe without announcing and count 60 seconds",
      "Use the stethoscope bell",
    ], answer: 2, rationale: "If you announce, the rate may change; count a full minute for accuracy." },
  { id: 5, q: "Which statement about catheter care is CORRECT?", options: [
      "Clean from catheter outward toward meatus",
      "Clean from meatus outward along catheter ~4 inches",
      "Scrub back-and-forth over meatus",
      "Tug gently to check placement",
    ], answer: 1, rationale: "Always clean away from the meatus along the catheter with a clean area each stroke." },
  { id: 6, q: "For perineal care (female), the direction of cleansing is…", options: [
      "Back to front",
      "Front to back",
      "Side to side",
      "Circular",
    ], answer: 1, rationale: "Front-to-back prevents bringing contaminants toward the urethra." },
  { id: 7, q: "Recording urinary output requires accuracy within…", options: ["±10 mL", "±25 mL", "±50 mL", "±100 mL"], answer: 1, rationale: "Most exams require ±25 mL tolerance." },
  { id: 8, q: "When feeding a resident, you should FIRST…", options: [
      "Offer fluid",
      "Verify the diet card matches the resident",
      "Add salt for taste",
      "Lower HOB to 30°",
    ], answer: 1, rationale: "Always verify correct resident and diet before starting." },
  { id: 9, q: "For dressing with an affected (weak) arm, remember to…", options: [
      "Dress the strong arm first",
      "Undress the weak arm first",
      "Dress the weak arm first",
      "Keep both arms elevated",
    ], answer: 2, rationale: "Dress weak first, undress strong first to protect the affected side." },
  { id: 10, q: "Which action is a CRITICAL safety step during transfers?", options: [
      "Unlock wheelchair before pivot",
      "Apply gait belt snugly (two-finger rule)",
      "Have client hold your neck",
      "Leave footrests down while standing",
    ], answer: 1, rationale: "Belt snug + locked wheels + footrests out are key to safe transfers." },
  { id: 11, q: "Where should the client’s arm be when measuring BP?", options: [
      "Above heart level",
      "At heart level, supported, palm up",
      "Hanging off the bed",
      "Crossed over chest",
    ], answer: 1, rationale: "Arm at heart level prevents false readings." },
  { id: 12, q: "Radial pulse must be recorded within…", options: ["±2 bpm", "±4 bpm", "±6 bpm", "±10 bpm"], answer: 1, rationale: "Typical tolerance is ±4 beats per minute." },
  { id: 13, q: "For ROM shoulder, you should…", options: [
      "Move quickly to finish in time",
      "Ask about pain and stop if painful",
      "Force past resistance for flexibility",
      "Rotate only the elbow joint",
    ], answer: 1, rationale: "Support joints, move slowly, stop with pain." },
  { id: 14, q: "Foot care includes…", options: [
      "Applying lotion between toes",
      "Skipping drying between toes",
      "Warm soak, dry between toes, lotion top/bottom only",
      "Clipping toenails",
    ], answer: 2, rationale: "Moisture between toes increases infection risk." },
  { id: 15, q: "A key evaluator priority across all skills is…", options: [
      "Speed over accuracy",
      "Privacy, infection control, safety",
      "Explaining less to save time",
      "Standing behind the resident silently",
    ], answer: 1, rationale: "Safety + infection control + privacy are universally critical." },
  { id: 16, q: "When weighing a resident on a standing scale…", options: [
      "Read the scale from above your head",
      "Zero the scale before use and record to correct unit",
      "Have the resident hold the rail while reading",
      "Estimate if they move",
    ], answer: 1, rationale: "Zeroing and eye-level reading reduce error; record precisely." },
  { id: 17, q: "After removing contaminated gloves, the NEXT step is…", options: [
      "Put on new gloves",
      "Hand hygiene",
      "Disinfect the floor",
      "Adjust linens",
    ], answer: 1, rationale: "Always perform hand hygiene immediately after glove removal." },
  { id: 18, q: "During bedpan use, which action protects dignity AND safety?", options: [
      "Keep bed flat for comfort",
      "Raise HOB and provide tissue and hand wipe within reach",
      "Stand in doorway",
      "Remove call light",
    ], answer: 1, rationale: "Upright position aids elimination and dignity; supplies within reach." },
  { id: 19, q: "Respirations normal adult range is…", options: [
      "6–10",
      "10–16",
      "12–20",
      "20–28",
    ], answer: 2, rationale: "12–20 breaths/min is typical for a healthy adult." },
  { id: 20, q: "Which statement about documentation is BEST?", options: [
      "Round numbers to make charting easier",
      "Record exactly what you measured and observed",
      "Use trailing zeros for decimals",
      "If unsure, fill later from memory",
    ], answer: 1, rationale: "Document precisely, no trailing zeros, never guess." },
];

function useDarkMode() {
  const [dark, setDark] = React.useState(false);
  React.useEffect(() => {
    const root = document.documentElement;
    if (dark) root.classList.add("dark");
    else root.classList.remove("dark");
  }, [dark]);
  return { dark, setDark };
}

function useChecklistState() {
  const [checked, setChecked] = React.useState<Record<string, boolean[]>>({});
  React.useEffect(() => {
    const saved = localStorage.getItem("cna_checked");
    if (saved) setChecked(JSON.parse(saved));
  }, []);
  React.useEffect(() => {
    localStorage.setItem("cna_checked", JSON.stringify(checked));
  }, [checked]);
  const toggle = (skillId: string, i: number) =>
    setChecked((prev) => {
      const arr = prev[skillId] ? [...prev[skillId]] : Array(skills.find(s=>s.id===skillId)?.critical.length||0).fill(false);
      arr[i] = !arr[i];
      return { ...prev, [skillId]: arr };
    });
  const reset = (skillId: string) =>
    setChecked((prev) => ({ ...prev, [skillId]: Array(skills.find(s=>s.id===skillId)?.critical.length||0).fill(false) }));
  return { checked, toggle, reset };
}

function QuizCard() {
  const [idx, setIdx] = React.useState(0);
  const [choice, setChoice] = React.useState<number | number[] | null>(null);
  const [score, setScore] = React.useState(0);
  const [showAns, setShowAns] = React.useState(false);
  const q = sampleQuestions[idx];

  const select = (i: number) => {
    if (q.multi) {
      const arr = Array.isArray(choice) ? [...choice] : [];
      const at = arr.indexOf(i);
      if (at >= 0) arr.splice(at, 1); else arr.push(i);
      setChoice(arr);
    } else {
      setChoice(i);
    }
  };

  const submit = () => {
    if (showAns) return;
    let correct = false;
    if (q.multi) {
      const a = (q.answer as number[]).sort().join(",");
      const c = (Array.isArray(choice) ? choice : []).sort().join(",");
      correct = a === c;
    } else {
      correct = choice === q.answer;
    }
    if (correct) setScore((s) => s + 1);
    setShowAns(true);
  };

  const next = () => {
    setIdx((i) => (i + 1) % sampleQuestions.length);
    setChoice(null);
    setShowAns(false);
  };

  return (
    <Card className="rounded-2xl">
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><GraduationCap className="h-5 w-5"/>Practice Quiz</CardTitle>
        <p className="text-sm text-zinc-500">Score: {score}</p>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="font-medium">Q{idx + 1}. {q.q}</p>
        <div className="space-y-2">
          {q.options.map((opt, i) => (
            <label key={i} className={`flex items-center gap-3 rounded-lg border p-3 ${showAns && ((q.multi ? (q.answer as number[]).includes(i) : q.answer === i) ? 'border-green-500' : (Array.isArray(choice) ? choice.includes(i) : choice===i) ? 'border-red-500' : 'border-zinc-200')} `}>
              <input
                type={q.multi ? "checkbox" : "radio"}
                name={`q-${q.id}`}
                checked={q.multi ? Array.isArray(choice) && choice.includes(i) : choice === i}
                onChange={() => select(i)}
              />
              <span>{opt}</span>
            </label>
          ))}
        </div>
        {!showAns ? (
          <Button onClick={submit} className="w-full">Submit</Button>
        ) : (
          <div className="space-y-3">
            <p className="text-sm"><strong>Answer:</strong> {q.multi ? (q.answer as number[]).map(i=>q.options[i]).join(", ") : q.options[q.answer as number]}</p>
            <p className="text-sm text-zinc-600 dark:text-zinc-300">{q.rationale}</p>
            <Button variant="outline" onClick={next} className="w-full">Next</Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function CNAGuide() {
  const { dark, setDark } = useDarkMode();
  const { checked, toggle, reset } = useChecklistState();
  const [query, setQuery] = React.useState("");

  const filtered = skills.filter((s) =>
    [s.name, s.category].join(" ").toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-white text-zinc-900 antialiased dark:bg-zinc-950 dark:text-zinc-50">
      {/* Top Bar */}
      <div className="w-full bg-zinc-100 py-2 text-center text-sm tracking-wide dark:bg-zinc-900">
        <span className="inline-flex items-center gap-2">
          <Stethoscope className="h-4 w-4" /> CNA Skills Exam — Critical Steps, Checklists, and Rapid Drills
        </span>
      </div>

      {/* Header */}
      <header className="sticky top-0 z-40 w-full border-b border-zinc-200 bg-white/80 backdrop-blur dark:border-zinc-800 dark:bg-zinc-950/80">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
          <a href="#home" className="text-xl font-black tracking-tight">CNA.GUIDE<span className="text-zinc-400">®</span></a>
          <nav className="hidden items-center gap-6 md:flex">
            <a href="#skills" className="hover:opacity-80">Skills</a>
            <a href="#practice" className="hover:opacity-80">Practice</a>
            <a href="#planner" className="hover:opacity-80">Planner</a>
            <a href="#resources" className="hover:opacity-80">Resources</a>
            <a href="#faq" className="hover:opacity-80">FAQ</a>
            <a href="#contact" className="hover:opacity-80">Contact</a>
          </nav>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => window.print()}><FileDown className="mr-2 h-4 w-4"/>Print PDF</Button>
            <Button variant="outline" size="icon" aria-label="Toggle dark mode" onClick={() => setDark(!dark)}>
              {dark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden"><Menu className="h-5 w-5"/></Button>
              </SheetTrigger>
              <SheetContent side="right">
                <SheetHeader>
                  <SheetTitle>Navigate</SheetTitle>
                </SheetHeader>
                <div className="mt-4 grid gap-3 text-sm">
                  {[
                    ["Skills", "#skills"],
                    ["Practice", "#practice"],
                    ["Planner", "#planner"],
                    ["Resources", "#resources"],
                    ["FAQ", "#faq"],
                    ["Contact", "#contact"],
                  ].map(([label, href]) => (
                    <a key={href} href={href as string} className="rounded-lg border p-3">{label}</a>
                  ))}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section id="home" className="relative">
        <div className="mx-auto grid max-w-6xl grid-cols-1 gap-8 px-4 py-14 md:grid-cols-2">
          <div className="flex flex-col justify-center gap-6">
            <Badge className="w-fit">Exam Ready • 2025</Badge>
            <h1 className="text-4xl font-extrabold leading-tight md:text-5xl">
              CNA Skills — simplified, structured, and pass-focused.
              <span className="block text-zinc-500">Built for fast reps and clean muscle memory.</span>
            </h1>
            <p className="max-w-prose text-zinc-600 dark:text-zinc-300">
              Use the critical-step checklists, run the mini‑quizzes, and print your planner. No fluff, just what evaluators grade.
            </p>
            <div className="flex flex-wrap gap-3">
              <Button asChild><a href="#skills"><ListChecks className="mr-2 h-4 w-4"/>Open Skills</a></Button>
              <Button variant="outline" asChild><a href="#practice"><GraduationCap className="mr-2 h-4 w-4"/>Start Quiz</a></Button>
            </div>
          </div>
          <Card className="rounded-2xl">
            <CardHeader>
              <CardTitle>Quick Search</CardTitle>
              <p className="text-sm text-zinc-500">Find any skill or category.</p>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 rounded-xl border p-2">
                <Search className="h-4 w-4"/>
                <input value={query} onChange={(e)=>setQuery(e.target.value)} className="w-full bg-transparent p-2 outline-none" placeholder="Try 'catheter', 'BP', or 'hand hygiene'"/>
              </div>
              <div className="mt-4 grid gap-2 text-sm">
                {filtered.slice(0,4).map((s)=> (
                  <a key={s.id} href={`#${s.id}`} className="rounded-lg border p-3 hover:bg-zinc-50 dark:hover:bg-zinc-900">
                    <span className="font-medium">{s.name}</span>
                    <span className="ml-2 text-zinc-500">• {s.category}</span>
                  </a>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Skills */}
      <section id="skills" className="border-t border-zinc-200 bg-zinc-50 py-16 dark:border-zinc-800 dark:bg-zinc-950">
        <div className="mx-auto max-w-6xl px-4">
          <div className="mb-6 flex items-end justify-between">
            <div>
              <h2 className="text-2xl font-bold">Critical Skills Checklists</h2>
              <p className="text-sm text-zinc-600 dark:text-zinc-300">Track your steps. Reset anytime. Print when ready.</p>
            </div>
            <Button variant="ghost" onClick={()=>localStorage.removeItem('cna_checked')}>Reset All</Button>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            {filtered.map((s) => (
              <Card id={s.id} key={s.id} className="rounded-2xl">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{s.name}</span>
                    <span className="text-sm font-normal text-zinc-500">{s.time}</span>
                  </CardTitle>
                  <p className="text-sm text-zinc-500">Category: {s.category}</p>
                </CardHeader>
                <CardContent className="space-y-3">
                  <ul className="space-y-2">
                    {s.critical.map((step, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <Checkbox id={`${s.id}-${i}`} checked={checked[s.id]?.[i] || false} onCheckedChange={() => toggle(s.id, i)} />
                        <label htmlFor={`${s.id}-${i}`} className="leading-relaxed">{step}</label>
                      </li>
                    ))}
                  </ul>
                  <div className="flex gap-2 pt-2">
                    <Button size="sm" variant="outline" onClick={()=>reset(s.id)}><ClipboardCheck className="mr-2 h-4 w-4"/>Reset</Button>
                    <Button size="sm" variant="ghost" asChild><a href="#practice">Test Me</a></Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Practice */}
      <section id="practice" className="py-16">
        <div className="mx-auto max-w-6xl px-4">
          <h2 className="mb-6 text-2xl font-bold">Practice Zone</h2>
          <div className="grid gap-6 md:grid-cols-2">
            <QuizCard />
            <Card className="rounded-2xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Clock className="h-5 w-5"/>Timed Reps</CardTitle>
                <p className="text-sm text-zinc-500">Set a 3–6 minute timer and run a skill from memory. Speak steps aloud.</p>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="3">
                  <TabsList>
                    <TabsTrigger value="3">3 min</TabsTrigger>
                    <TabsTrigger value="5">5 min</TabsTrigger>
                    <TabsTrigger value="6">6 min</TabsTrigger>
                  </TabsList>
                  {([3,5,6] as const).map((n)=> (
                    <TabsContent key={n} value={String(n)}>
                      <Button className="w-full" onClick={() => {
                        const end = Date.now() + n*60*1000;
                        const tick = setInterval(() => {
                          if (Date.now() >= end) { clearInterval(tick); alert(`${n} minutes done — pens down!`); }
                        }, 1000);
                        alert(`Timer started: ${n} minutes`);
                      }}>Start {n}-minute Timer</Button>
                    </TabsContent>
                  ))}
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Planner */}
      <section id="planner" className="border-t border-zinc-200 bg-zinc-50 py-16 dark:border-zinc-800 dark:bg-zinc-950">
        <div className="mx-auto max-w-6xl px-4">
          <h2 className="mb-4 text-2xl font-bold">Study Planner (7‑Day Sprint)</h2>
          <div className="grid gap-6 md:grid-cols-2">
            <Card className="rounded-2xl">
              <CardHeader><CardTitle>Schedule</CardTitle></CardHeader>
              <CardContent className="space-y-2 text-sm">
                <p><strong>Day 1:</strong> Infection Control — Hand hygiene, PPE (3× reps each)</p>
                <p><strong>Day 2:</strong> Vitals — BP, Pulse, Resp (2× reps + 20 MCQs)</p>
                <p><strong>Day 3:</strong> Hygiene — Mouth care, Catheter care</p>
                <p><strong>Day 4:</strong> Elimination — Bedpan, Urinary output</p>
                <p><strong>Day 5:</strong> Mobility — Ambulation, Transfer, Positioning</p>
                <p><strong>Day 6:</strong> Mixed Mock Exam (timer + checklists)</p>
                <p><strong>Day 7:</strong> Light review + rest, sleep 8h before exam</p>
              </CardContent>
            </Card>
            <Card className="rounded-2xl">
              <CardHeader><CardTitle>Downloadables</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full" onClick={()=>window.print()}><FileDown className="mr-2 h-4 w-4"/>Print Planner & Checklists</Button>
                <p className="text-xs text-zinc-500">Use your browser’s Print to save a PDF. We’ll add a dedicated PDF soon.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Resources */}
      <section id="resources" className="py-16">
        <div className="mx-auto max-w-6xl px-4">
          <h2 className="mb-6 text-2xl font-bold">Resources</h2>
          <div className="grid gap-6 md:grid-cols-3">
            <Card className="rounded-2xl">
              <CardHeader><CardTitle>Evaluator Mindset</CardTitle></CardHeader>
              <CardContent className="text-sm text-zinc-600 dark:text-zinc-300">
                Safety first (locks, shoes, call light), infection control (hand hygiene, gloves), privacy, and accurate recording. Speak steps.
              </CardContent>
            </Card>
            <Card className="rounded-2xl">
              <CardHeader><CardTitle>Supplies Checklist</CardTitle></CardHeader>
              <CardContent className="text-sm">
                Gloves, gown, paper towels, linens, basin, soap, toothpaste/brush, emesis/urinal, bedpan, measuring container, gait belt, BP cuff & stethoscope.
              </CardContent>
            </Card>
            <Card className="rounded-2xl">
              <CardHeader><CardTitle>Documentation Tips</CardTitle></CardHeader>
              <CardContent className="text-sm">
                Record exactly, avoid trailing zeros, note patient tolerance, report abnormals promptly. When unsure, ask nurse — never guess.
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="border-t border-zinc-200 bg-zinc-50 py-16 dark:border-zinc-800 dark:bg-zinc-950">
        <div className="mx-auto max-w-6xl px-4">
          <h2 className="mb-6 text-2xl font-bold">FAQ</h2>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="f1">
              <AccordionTrigger>What if I make a small mistake?</AccordionTrigger>
              <AccordionContent>Correct yourself out loud and continue. Only critical‑step failures or safety breaches cause automatic fail.</AccordionContent>
            </AccordionItem>
            <AccordionItem value="f2">
              <AccordionTrigger>Do I have to memorize word‑for‑word scripts?</AccordionTrigger>
              <AccordionContent>No. Speak clearly, hit infection control, safety, privacy, and the critical steps. Check resident comfort.</AccordionContent>
            </AccordionItem>
            <AccordionItem value="f3">
              <AccordionTrigger>How should I practice timing?</AccordionTrigger>
              <AccordionContent>Run 3–6 minute sprints, then a full mock with two skills back‑to‑back under timer. Aim to finish 30–60s early.</AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-16">
        <div className="mx-auto max-w-6xl px-4">
          <h2 className="mb-6 text-2xl font-bold">Contact</h2>
          <div className="grid gap-6 md:grid-cols-2">
            <form className="space-y-3">
              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                <Input placeholder="Name" />
                <Input placeholder="Email" type="email" />
              </div>
              <Textarea placeholder="Question, collab, or tutoring request" rows={5} />
              <Button className="px-6">Send</Button>
            </form>
            <Card className="rounded-2xl">
              <CardContent className="space-y-3 p-6 text-sm text-zinc-600 dark:text-zinc-300">
                <div className="flex items-center gap-2"><Mail className="h-4 w-4"/> hello@cna.guide</div>
                <div className="flex items-center gap-2"><Phone className="h-4 w-4"/> +1 (555) 000‑1234</div>
                <p className="pt-2 text-xs text-zinc-500">This site is a study aid. Always follow your program/state testing rules.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-zinc-200 py-10 text-sm dark:border-zinc-800">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 md:flex-row">
          <p>© {new Date().getFullYear()} CNA.GUIDE — All rights reserved.</p>
          <div className="flex items-center gap-4">
            <a href="#" className="hover:opacity-80">Terms</a>
            <a href="#" className="hover:opacity-80">Privacy</a>
          </div>
        </div>
      </footer>
    </div>
  );
}