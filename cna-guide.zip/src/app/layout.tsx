import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "CNA Guide",
  description: "CNA skills, checklists, practice, and planner",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>{children}</body>
    </html>
  );
}
