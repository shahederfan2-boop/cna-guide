# CNA Guide

A one-page CNA study site (skills checklists, practice quiz, timers, planner) built with Next.js + Tailwind.

## Dev
```bash
npm install
npm run dev
# open http://localhost:3000
```

## Deploy
Push this repo to GitHub and import into Vercel.
